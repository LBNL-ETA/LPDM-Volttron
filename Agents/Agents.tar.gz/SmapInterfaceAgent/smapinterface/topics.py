UPLOAD_REQUEST_TOPIC = "smapinterface/request/upload"
DOWNLOAD_REQUEST_TOPIC = "smapinterface/request/download"
UPLOAD_RESPONSE_TOPIC = "smapinterface/response/upload"
DOWNLOAD_RESPONSE_TOPIC = "smapinterface/response/download"

QUERY_REQUEST_TOPIC = "smapinterface/request/query"