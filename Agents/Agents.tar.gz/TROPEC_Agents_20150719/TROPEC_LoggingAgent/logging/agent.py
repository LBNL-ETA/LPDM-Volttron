# -*- coding: utf-8 -*- {{{
# vim: set fenc=utf-8 ft=python sw=4 ts=4 sts=4 et:


import sys
import requests
from requests import ConnectionError

from volttron.platform.agent import BaseAgent, PublishMixin
from volttron.platform.agent import utils
from volttron.platform.agent.utils import jsonapi
from volttron.platform.agent.matching import match_all, match_start, match_exact
from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import topics
from Agents.TROPEC_BaseAgent.base.topics import *
from Agents.SmapInterfaceAgent.smapinterface.topics import *

import json

def log_entry_and_exit(f):
    def _f(*args):
        print "Entering %s" % f.__name__
        f(*args)
        print "Exited %s" % f.__name__
    return _f

jan_1_2015 = 1420099200000

class TROPEC_LoggingAgent(PublishMixin, BaseAgent):
    def __init__(self, **kwargs):
        super(TROPEC_LoggingAgent, self).__init__(**kwargs)      
        self.scenario_id = "simulation"   
            
    @match_start(POWER_USE_TOPIC)
    def on_TROPEC_power_message(self, topic, headers, message, matched):
        message = jsonapi.loads(message[0])
        from_id = headers[headers_mod.FROM]
        timestamp = float(headers["timestamp"])
        power = message["power"]
        
        headers = {'SourceName': "TROPEC",                   
                   headers_mod.FROM : "TROPEC logger",
                   "SmapRoot" : "http://elnhv.lbl.gov/",
                   #'Stream' : "/simulation/{id}".format(id = from_id),
                   'Stream' : "{scenario_id}/{id}/power".format(scenario_id = self.scenario_id, id = from_id),
                   'ApiKey' : "3EYQy04hlPpA03SixKcRJaIreUrnpdYu9bNn",
                   'StreamUUID' : "USE EXISTING"                      
                   }
        metadata = {"UnitofMeasure" : "W", "Timezone" : "America/Los_Angeles"}
        
        msg = {"timeseries" : [[jan_1_2015 + int(timestamp * 1000), power]], "metadata" : metadata}                           
        
        self.publish_json(UPLOAD_REQUEST_TOPIC + "/TROPEC_Logging", headers, msg)
        
    @match_start(ENERGY_PRICE_TOPIC)
    def on_TROPEC_energy_price_message(self, topic, headers, message, matched):
        message = jsonapi.loads(message[0])
        from_id = headers[headers_mod.FROM]
        timestamp = float(headers["timestamp"])
        energy_price = message["price"]
        
        headers = {'SourceName': "TROPEC",
                   headers_mod.FROM : "TROPEC logger",
                   "SmapRoot" : "http://elnhv.lbl.gov/",
                   #'Stream' : "/simulation/{id}".format(id = from_id),
                   'Stream' : "{scenario_id}/{id}/price".format(scenario_id = self.scenario_id, id = from_id),
                   'ApiKey' : "3EYQy04hlPpA03SixKcRJaIreUrnpdYu9bNn",
                   'StreamUUID' : "USE EXISTING"                      
                   }
        metadata = {"UnitofMeasure" : "$/kWh", "Timezone" : "America/Los_Angeles"}
        
        msg = {"timeseries" : [[jan_1_2015 + int(timestamp * 1000), energy_price]], "metadata" : metadata}                           
        
        self.publish_json(UPLOAD_REQUEST_TOPIC + "/TROPEC_Logging", headers, msg)
        
    ##@match_start(TROPEC_BASE)
    @match_all
    def on_TROPEC_message(self, topic, headers, message, matched):
        with open("/tmp/TROPEC.log", "a") as f:
            f.write("{topic}\t{headers}\t{message}\n\n".format(topic = topic, headers = headers, message = message))
            
    @match_exact(SCENARIO_ID_TOPIC)
    def on_scenario_id_message(self, topic, headers, message, matched):
        message = json.loads(message[0])
        self.scenario_id = message.get("scenario_id", None)
        if self.scenario_id[0] != "/":
            self.scenario_id = "/" + self.scenario_id

def main(argv=sys.argv):
    '''Main method called by the eggsecutable.'''
    utils.default_main(TROPEC_LoggingAgent,
                       description='TROPEC Simulation Agent',
                       argv=argv)


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv))
    except KeyboardInterrupt:
        pass
