# -*- coding: utf-8 -*- {{{
# vim: set fenc=utf-8 ft=python sw=4 ts=4 sts=4 et:


import sys
import requests
from requests import ConnectionError

from volttron.platform.agent import BaseAgent, PublishMixin
from volttron.platform.agent import utils
from volttron.platform.agent.utils import jsonapi
from volttron.platform.agent.matching import match_all, match_start
from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import topics

import json
from topics import *

def log_entry_and_exit(f):
    def _f(*args):        
        print "Entering {f}".format(f = f.__name__)
        res = f(*args)
        print "Exited {f}".format(f = f.__name__)
        return res
    return _f



class TROPEC_BaseAgent(PublishMixin, BaseAgent):
    def __init__(self, **kwargs):
            super(TROPEC_BaseAgent, self).__init__(**kwargs)
            self.time = None            
            self.agent_id = kwargs["device_id"]
            self.last_message_id = None
            self.message_processing_time = .001
            #self.subscribe(TIME_UNTIL_NEXT_EVENT_TOPIC_GLOBAL, self.on_time_until_next_event_request)
            #self.subscribe(TIME_UNTIL_NEXT_EVENT_TOPIC_SPECIFIC_AGENT.format(id = self.agent_id), self.on_time_until_next_event_request)
    
#     def on_time_until_next_event_request(self, topic, headers, message, matched):
#         response_topics_and_messages = self.get_time_until_next_event(message)
#         self.send_response_messages(response_topics_and_messages, headers)
#         
#     def get_time_until_next_event(self, message):
#         raise NotImplementedError("Implement in derived class")
    
    def default_headers(self, target_device):
        from uuid import uuid1
        headers = {}
        headers[headers_mod.FROM] = self.agent_id
        if target_device:
            headers[headers_mod.TO] = target_device
        headers["timestamp"] = self.time        
        headers["responding_to"] = self.last_message_id
        headers["message_id"] = str(uuid1())
        
        return headers
    
#     def get_response_headers(self, headers):
#         from uuid import uuid1
#         headers[headers_mod.TO] = headers[headers_mod.FROM] if headers_mod.FROM in headers else "Unknown"
#         headers[headers_mod.FROM] = self.agent_id
#         #if "message_id" in headers:
#         #    headers["responding_to_message_id"] = headers["message_id"]
#         #try:
#         headers["responding_to"] = headers.get("message_id", None)
#         #if self.last_message_id:
#         #except:
#         #    headers["responding_to"] = None
#         headers["message_id"] = str(uuid1())
#         message_timestamp = self.get_time()
#         headers["timestamp"] = message_timestamp            
#         #headers["message_id"] = "{id} {ts}".format(id = self.agent_id, ts = message_timestamp)
#     
#         return headers
# 
#     @log_entry_and_exit
#     def send_response_messages(self, response_topics_and_messages, headers):
#         if response_topics_and_messages:
#             response_headers = self.get_response_headers(headers)
#             for topic, message in response_topics_and_messages.items():                
#                 self.publish_json(topic, response_headers, message)
    
    def get_time(self):
        raise NotImplementedError("Implement in derived class.")
  
    @log_entry_and_exit
    def send_new_price(self, source_device_id, target_device_id, timestamp, price):
        headers = self.default_headers(target_device_id)        
        headers["timestamp"] = timestamp + .001
        message = {"price" : price}
        topic = ENERGY_PRICE_TOPIC_SPECIFIC_AGENT.format(id = self.agent_id)
        #if target_device_id and target_device_id.lower != "all":
        #    topic = ENERGY_PRICE_TOPIC_SPECIFIC_AGENT.format(id = target_device_id)
        #else:
        #    topic = ENERGY_PRICE_TOPIC
        self.publish_json(topic, headers, message)
        
    @log_entry_and_exit
    def send_new_power(self, source_device_id, target_device_id, timestamp, power):
        headers = self.default_headers(target_device_id)     
        headers["timestamp"] = timestamp + .001
        message = {"power" : power}
        topic = POWER_USE_TOPIC_SPECIFIC_AGENT.format(id = self.agent_id)
        #if target_device_id and target_device_id.lower() != "all":
        #    topic = POWER_USE_TOPIC_SPECIFIC_AGENT.format(id = target_device_id)
        #else:
        #    topic = POWER_USE_TOPIC
        self.publish_json(topic, headers, message)
    
    @log_entry_and_exit
    def send_new_time_until_next_event(self, source_device_id, target_device_id, time_until_next_event):
        headers = self.default_headers(target_device_id)      
        message = {"time_until_next_event" : time_until_next_event}
        topic = TIME_UNTIL_NEXT_EVENT_TOPIC_SPECIFIC_AGENT.format(id = self.agent_id)
        
        #if target_device_id and target_device_id.lower() != "all":
        #    topic = TIME_UNTIL_NEXT_EVENT_TOPIC_SPECIFIC_AGENT.format(id = target_device_id)
        #else:
        #    topic = TIME_UNTIL_NEXT_EVENT_TOPIC_GLOBAL
        self.publish_json(topic, headers, message)
        
    def send_finished_initialization(self):
        headers = self.default_headers(None)            
        message = {"initialization_finished" : True}
        topic = FINISHED_INITIALIZING_TOPIC.format(id = self.agent_id)
        self.publish_json(topic, headers, message)
        
    def get_device(self):
        raise NotImplementedError("Implement in derived class.")
            

def main(argv=sys.argv):
    '''Main method called by the eggsecutable.'''
    utils.default_main(TROPEC_BaseAgent,
                       description='TROPEC Simulation Agent',
                       argv=argv)


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv))
    except KeyboardInterrupt:
        pass
