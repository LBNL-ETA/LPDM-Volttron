# -*- coding: utf-8 -*- {{{
# vim: set fenc=utf-8 ft=python sw=4 ts=4 sts=4 et:


import sys
import requests
from requests import ConnectionError

from volttron.platform.agent import BaseAgent, PublishMixin
from volttron.platform.agent import utils
from volttron.platform.agent.utils import jsonapi
from volttron.platform.agent.matching import match_all, match_start, match_exact
from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import topics
from Agents.TROPEC_BaseAgent.base.topics import *
from Agents.TROPEC_SimulationAgent.simulation.agent import SimulationAgent
from tug_devices.diesel_generator import DieselGenerator
import json

def log_entry_and_exit(f):
    def _f(*args):        
        print "Entering GeneratorAgent {f}".format(f = f.__name__)
        res = f(*args)
        print "Exited GeneratorAgent {f}".format(f = f.__name__)
        return res
    return _f

class GeneratorAgent(SimulationAgent):
    def __init__(self, **kwargs):
        super(GeneratorAgent, self).__init__(**kwargs)
        
        try:
            config = kwargs
            config["device_name"] = config["device_id"]
            self.grid_controller_id = config["grid_controller_id"]
        except:
            config = {}           
        config["broadcastNewPrice"] = self.send_new_price
        config["broadcastNewPower"] = self.send_new_power
        config["broadcastNewTTIE"] = self.send_new_time_until_next_event
        self.diesel_generator = DieselGenerator(config)
        self.subscribed_power_topic = POWER_USE_TOPIC_SPECIFIC_AGENT.format(id = self.agent_id)
        self.power_subscription_id = self.subscribe(self.subscribed_power_topic, self.on_power_update)
        self.broadcast_connection()
        self.send_subscriptions()
        self.send_finished_initialization()
#         self.subscribe(REQUEST_TOPIC, self.handle_request)
    @log_entry_and_exit
    def broadcast_connection(self):
        headers = self.default_headers(None)
        self.publish_json(ADD_GENERATOR_TOPIC.format(id = self.grid_controller_id), headers, {"agent_id" : self.agent_id})
    
    @log_entry_and_exit    
    def get_device(self):
        return self.diesel_generator
    
    @log_entry_and_exit
    def send_subscriptions(self):
        subscriptions = [self.subscribed_power_topic]        
        message = {"subscriptions" : subscriptions}
        headers = {}
        headers[headers_mod.FROM] = self.agent_id
        self.publish_json(SUBSCRIPTION_TOPIC, headers, message)  
    
    @log_entry_and_exit
    def on_power_update(self, topic, headers, message, matched):        
        message = jsonapi.loads(message[0])
        device_id = headers.get(headers_mod.FROM, None)
        message_id = headers.get("message_id", None)
        self.last_message_id = message_id
        power = message.get("power", None)
        timestamp = headers.get("timestamp", None)
        if timestamp > self.time:
            self.time = timestamp
        self.diesel_generator.onPowerChange(device_id, self.diesel_generator._device_id, self.time, power)
        
#    @match_exact(POWER_USE_TOPIC)
#    @log_entry_and_exit
#    def on_power_update_message(self, topic, headers, message, matched):        
#        self.on_power_update(topic, headers, message, matched)                

def main(argv=sys.argv):
    '''Main method called by the eggsecutable.'''
    utils.default_main(GeneratorAgent,
                       description='TROPEC Generator Agent',
                       argv=argv)


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv))
    except KeyboardInterrupt:
        pass
