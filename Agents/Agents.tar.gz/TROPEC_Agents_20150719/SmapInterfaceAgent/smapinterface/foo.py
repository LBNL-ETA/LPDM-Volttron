from smap_download_data import download_data

streams = [ "/Meter2/elt-B/ABC/true_power",
            "/Meter1/elt-B/ABC/true_power",
            "/Meter1/elt-C/ABC/true_power",
            "/Meter1/elt-E/ABC/true_power"]

for stream in streams:
    data, timezone = download_data("http://smap.lbl.gov/", stream)

    with open("/tmp/{f}.csv".format(f = stream.replace("/", "_")), "w" ) as f:
        for r in data:        
            f.write("{ts},{v}\n".format(ts = r[0], v = r[1]))