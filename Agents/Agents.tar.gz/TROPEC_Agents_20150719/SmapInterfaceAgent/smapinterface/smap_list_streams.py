#! /usr/bin/env python

'''
This program lists all streams, with their paths and uuids, in a smap
database.  It optionally organizes streams by whether they are or are
not in the smap database.
'''

__author__ = "Nathan Addy <naddy@lbl.gov>"

from optparse import OptionParser
from smap.archiver.client import SmapClient
import sys
import os
import time
import datetime
import logging

APP_NAME="smap-list-streams"

def configGlobalLogger():
    # Configure the Global Application Logger.  Just some basic screen
    # logging.
    BASIC_MODULE_LOGGING_LEVEL = logging.INFO
    app_logger = getAppLogger()
    app_logger.setLevel(BASIC_MODULE_LOGGING_LEVEL)
    formatter = logging.Formatter('%(levelname)s - %(message)s')
    ch = logging.StreamHandler()
    ch.setLevel(BASIC_MODULE_LOGGING_LEVEL)
    ch.setFormatter(formatter)
    app_logger.addHandler(ch)
    return 

def getAppLogger():
    return logging.getLogger('smap_list_streams_logger')

def doListPaths(url):
    paths = getPaths(url)
    paths.sort(key = lambda x: x["Path"])
    res = []
    for p in paths:
        res.append("%s - %s" % (p["Path"], p["uuid"]))
    return res

def doListOrphanPaths(url):
    c = SmapClient(url)

    # There must be a more efficient way to do this than downloading
    # every object.
    objects = c.query("select Path, uuid, Metadata/SourceName")
    orphans = []
    res = []
    
    for obj in objects:
        if obj["Metadata"]["SourceName"] == None:
            orphans.append(obj)
    else:
        orphans.sort(key = lambda obj: obj["Path"])
        for obj in orphans:
            res.append("%s - %s" % (obj["Path"], obj["uuid"]))
    return res

def doListPathsBySource(url):
    sources = getSources(url)
    sources.sort()

    c = SmapClient(url)
    res = []
    for src in sources:
        res.append("Metadata/SourceName=%s" % src)
        
        math_obj = c.tags("""Metadata/SourceName=\"%s\"""" % src)
        for obj in math_obj:
            res.append("\t%s - %s" % (obj["Path"], obj["uuid"]))
    return res

def getPaths(url):
    smap_client = SmapClient(url)
    paths = smap_client.query("select Path, uuid")
    return paths

def getSources(url):
    """Get the list of sources from the source"""
    smap_client = SmapClient(url)    
    return smap_client.query("select distinct Metadata/SourceName")

def main(args=None):
    print "starting smap_list_streams main"
    configGlobalLogger()
    
    usage = """Usage:
    %s                 List all paths in the object database.
    %s --source        List all paths, hierarchically organized by Metadata/SourceName, the same way the webside does it.
    %s --no-source     List all paths that do not have a Metadata/SourceName tag, and therefore do not show up online.
    """ % (APP_NAME, APP_NAME, APP_NAME)

    parser = OptionParser(usage)
    parser.add_option("-s", "--source", dest="group_by_source", default = False, action="store_true")
    parser.add_option("-n", "--no-source", dest="find_null_paths", default = False, action="store_true")
    parser.add_option("-u", "--url", dest="url", default = "https://smap.lbl.gov", \
                      help="The name of the smap database to query.")

    (option, args) = parser.parse_args(args)
    if option.group_by_source and option.find_null_paths:
        getAppLogger().critical("--source and --no-source cannot both be set.")
        sys.exit(1)

    if len(args):
        getAppLogger().critical("Bad command line argument '%s'. Program takes no arguments" % ",".join(map(str, args)))
        sys.exit(1)

    url = option.url + "/backend"

    if option.group_by_source:
        res = doListPathsBySource(url)
    elif option.find_null_paths:
        res = doListOrphanPaths(url)
    else:
        res = doListPaths(url)
    print "ending smap_list_streams main"        
    return res

if __name__ == '__main__':
    strs = main()
    for s in strs:
        print s
    
