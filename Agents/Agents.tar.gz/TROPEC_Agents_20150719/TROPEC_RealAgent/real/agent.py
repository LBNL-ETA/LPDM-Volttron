# -*- coding: utf-8 -*- {{{
# vim: set fenc=utf-8 ft=python sw=4 ts=4 sts=4 et:


import sys
import requests
from requests import ConnectionError

from volttron.platform.agent import BaseAgent, PublishMixin
from volttron.platform.agent import utils
from volttron.platform.agent.utils import jsonapi
from volttron.platform.agent.matching import match_all, match_start
from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import topics
from Agents.TROPEC_BaseAgent.base.topics import *
from Agents.TROPEC_BaseAgent.base.agent import TROPEC_BaseAgent

import json

def log_entry_and_exit(f):
    def _f(*args):
        print "Entering %s" % f.__name__
        f(*args)
        print "Exited %s" % f.__name__
    return _f



class RealAgent(TROPEC_BaseAgent):
    def __init__(self, **kwargs):
        super(RealAgent, self).__init__(**kwargs)
        self.time = None

    def get_time(self):
        from time import time
        return time()
    
    
            

def main(argv=sys.argv):
    '''Main method called by the eggsecutable.'''
    utils.default_main(RealAgent,
                       description='TROPEC Real (non-simulation) Agent',
                       argv=argv)


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv))
    except KeyboardInterrupt:
        pass
