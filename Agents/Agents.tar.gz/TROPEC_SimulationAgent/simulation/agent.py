# -*- coding: utf-8 -*- {{{
# vim: set fenc=utf-8 ft=python sw=4 ts=4 sts=4 et:


import sys
import requests
from requests import ConnectionError

from volttron.platform.agent import BaseAgent, PublishMixin
from volttron.platform.agent import utils
from volttron.platform.agent.utils import jsonapi
from volttron.platform.agent.matching import match_all, match_start
from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import topics
from Agents.TROPEC_BaseAgent.base.topics import *
from Agents.TROPEC_BaseAgent.base.agent import TROPEC_BaseAgent
import json


def log_entry_and_exit(f):
    def _f(*args):
        print "Entering %s" % f.__name__
        f(*args)
        print "Exited %s" % f.__name__
    return _f



class SimulationAgent(TROPEC_BaseAgent):
    def __init__(self, **kwargs):
            super(SimulationAgent, self).__init__(**kwargs)
            self.time = 0
            self.time_topic_registration_id = self.subscribe(SYSTEM_TIME_TOPIC_SPECIFIC_AGENT.format(id = self.agent_id), self.on_time_update)

    #@match_start(SYSTEM_TIME_TOPIC)
    @log_entry_and_exit
    def on_time_update(self, topic, headers, message, matched):        
        message = jsonapi.loads(message[0])
        timestamp = message["timestamp"]
        self.last_message_id = headers.get("message_id", None)
        self.time = float(timestamp)
        print "Time:\t{s}".format(s = self.time)
        device = self.get_device()
        if timestamp >= 64800:
            qq = 6
            qq
        device.onTimeChange(self.time)
        
    def get_time(self):
        return self.time
            

def main(argv=sys.argv):
    '''Main method called by the eggsecutable.'''
    utils.default_main(SimulationAgent,
                       description='TROPEC Simulation Agent',
                       argv=argv)


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv))
    except KeyboardInterrupt:
        pass
