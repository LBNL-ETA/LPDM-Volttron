# -*- coding: utf-8 -*- {{{
# vim: set fenc=utf-8 ft=python sw=4 ts=4 sts=4 et:


import sys
import requests
from requests import ConnectionError

from volttron.platform.agent import BaseAgent, PublishMixin, periodic
from volttron.platform.agent import utils
from volttron.platform.agent.utils import jsonapi
from volttron.platform.agent.matching import match_all, match_start
from volttron.platform.messaging import headers as headers_mod
from volttron.platform.messaging import topics

import threading

from Agents.TROPEC_SimulationAgent.simulation.agent import SimulationAgent
from Agents.TROPEC_EndUseDeviceAgent.endusedevice.agent import EndUseDeviceAgent
from Agents.TROPEC_GridControllerAgent.gridcontroller.agent import GridControllerAgent
from Agents.TROPEC_GeneratorAgent.generator.agent import GeneratorAgent
from Agents.TROPEC_BaseAgent.base.topics import *

def log_entry_and_exit(f):
    def _f(*args):
        print "Entering %s" % f.__name__
        f(*args)
        print "Exited %s" % f.__name__
    return _f



class SupervisorAgent(PublishMixin, BaseAgent):
    def __init__(self, **kwargs):
        super(SupervisorAgent, self).__init__(**kwargs)
        self.available_agent_types = {"End_Use_Device" : EndUseDeviceAgent, "Grid_Controller" : GridControllerAgent, "Generator" : GeneratorAgent}                
        self.time = 0
        self.agent_id = 0
        self.managed_agent_information = {} #key is agent_id, value is dict with keys agent_time_topic and agent_next_event_topic
        self.times_until_next_event = {}
        self.agent_threads = self.process_scenario_file("./Agents/TROPEC_SupervisorAgent/supervisor/scenarios/test_scenario.json")
        self.start_agents(self.agent_threads)
        self.end_use_devices = []
        self.generators = []
        self.grid_controllers = []
#        print "Starting a SimulationAgent"
#        kw = {"agent_id" : 1}
#        self.t = threading.Thread(target = utils.default_main, args = (SimulationAgent, "SimulationAgent Started From Supervisor"), kwargs = kw)
#        self.t.start()
#        self.times_until_next_event = {}
#        print "Finsihed creating a SimulationAgent"
#        print "SupervisorAgent Init done"
        
    def start_agents(self, agent_threads):
        #first start grid_controlelrs.  These are the real managers of the system and so should start first
        for t in agent_threads["Grid_Controller"]:
            t.start()
        
        #next start generators.  They are the things that actually provide power so no point having anything
        #using power without something to provide the power
        for t in agent_threads["Generator"]:
            t.start()
            
        #finally start end_use_devices
        for t in agent_threads["End_Use_Device"]:
            t.start()        
        
    def process_scenario_file(self, fname):
        import json
        
        
        with open(fname, "r") as f:
            scenario = json.load(f)
            
        agent_threads = {"Grid_Controller" : [], "End_Use_Device" : [], "Generator" : []}
            
        for agent_type, agent_params in scenario.items():
            if agent_type not in self.available_agent_types:
                raise RuntimeError("Unknown agent type:\t{s}".format(s = agent_type))
            
            t = threading.Thread(target = utils.default_main, 
                                 args = (self.available_agent_types[agent_type], "{s} Agent started by supervisor".format(s = agent_type)), 
                                 kwargs = agent_params)
                                 
            agent_threads[agent_type].append(t)
            self.times_until_next_event[agent_params["device_id"]] = {"responding_to_message_id" : None, "timestamp" : None, "time_until_next_event" : None}
            
        return agent_threads
            

    def send_next_event_request(self, agent_id):
        headers = {}        
        headers[headers_mod.FROM] = self.agent_id
        message_timestamp = self.time
        headers["sent_time"] = message_timestamp
        headers["message_id"] = "{id} {ts}".format(id = self.agent_id, ts = message_timestamp)        
        message = {"information_request" : "next_event"}
        self.expected_next_event_replies[agent_id] = {"message_id" : headers["message_id"], "response_message" : None, "response_headers" : None}
        self.post_json(self.managed_agent_information[agent_id]["agent_next_event_topic"], headers, message)
        
    def poll_for_next_event(self, agent_ids = None):
        self.expected_next_event_replies = {}
        
        if not agent_ids:
            agent_ids = self.managed_agent_information.keys()
            
        for agent_id in agent_ids:
            self.send_next_event_request(agent_id)
            
    #@periodic(5)
    def update_time(self):
        print "Sending Update Time Message"
        topic = "system_time"
        headers = {}
        headers[headers_mod.FROM] = self.agent_id
        message = {"time" : self.time}
        self.publish_json(topic, headers, message)
        self.time += 1            

    @match_start("energy_price")
    @log_entry_and_exit
    def on_energy_price_announcement(self, topic, headers, message, matched):
        pass
    
    @match_start("power_use")
    @log_entry_and_exit
    def on_power_consumption_announcement(self, topic, headers, message, matched):
        pass
    
#     @match_start(TIME_UNTIL_NEXT_EVENT_TOPIC_GLOBAL)
#     def on_time_until_next_event_announcement(self, topic, headers, message, matched):
#         message = jsonapi.loads(message[0])
#         time_until_next_event = message["time_until_next_event"]
#         agent_id = headers[headers_mod.FROM]
#         timestamp = headers["timestamp"]
#         self.times_until_next_event[agent_id] = {"message_timestamp" : float(timestamp), "time_until_next_event" : float(time_until_next_event)}
#         self.check_all_agents_ready_for_next_time()
    
    @match_start(TIME_UNTIL_NEXT_EVENT_TOPIC_GLOBAL)
    @log_entry_and_exit
    def on_time_until_next_event(self, topic, headers, message, matched):
        message = jsonapi.loads(message[0])
        agent = headers[headers_mod.FROM]
        responding_to = headers.get("message_id", None)
        timestamp = headers.get("timestamp", None)
        time_until_next_event = message["time_until_next_event"]
        self.times_until_next_event[agent] = {"responding_to_message_id" : responding_to, "timestamp" : timestamp, "time_until_next_event" : time_until_next_event}
        self.check_all_agents_ready_for_next_time()
        
    def check_all_agents_ready_for_next_time(self):
        earliest_next_event = 1e100
        last_message_timestamp = self.times_until_next_event.values()[0]["timestamp"]
        for agent_id, values in self.times_until_next_event.items():
            ttie = values["time_until_next_event"]
            message_timestamp = values["timestamp"]
            if not ttie or last_message_timestamp != message_timestamp:
                return
            if ttie < earliest_next_event:
                earliest_next_event = ttie
                
        self.send_new_time(earliest_next_event)
        
    def send_new_time(self, timestamp):
        headers = {}
        headers[headers_mod.FROM] = self.agent_id
        headers["timestamp"] = timestamp
        message = {"timestamp" : timestamp}
        
        self.publish_json(SYSTEM_TIME_TOPIC, headers, message)
        

def main(argv=sys.argv):
    '''Main method called by the eggsecutable.'''
    utils.default_main(SupervisorAgent,
                       description='TROPEC Supervisor Agent',
                       argv=argv)


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv))
    except KeyboardInterrupt:
        pass
