# -*- coding: utf-8 -*- {{{
# vim: set fenc=utf-8 ft=python sw=4 ts=4 sts=4 et:


import sys
import requests
from requests import ConnectionError

from volttron.platform.agent import BaseAgent, PublishMixin
from volttron.platform.agent import utils
from volttron.platform.agent.utils import jsonapi
from volttron.platform.agent.matching import match_all, match_start, match_exact
from volttron.platform.messaging import headers as headers_mod
from Agents.TROPEC_SimulationAgent.simulation.agent import SimulationAgent
#from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import topics

import json
from Agents.TROPEC_BaseAgent.base.topics import *
from tug_devices.grid_controller import GridController


def log_entry_and_exit(f):
    def _f(*args):
        print "Entering %s" % f.__name__
        f(*args)
        print "Exited %s" % f.__name__
    return _f


class GridControllerAgent(SimulationAgent):
   
    def __init__(self, **kwargs):
            #super(BaseAgent, self).__init__(**kwargs)
            super(GridControllerAgent, self).__init__(**kwargs)
            self.generators = {}
            self.end_use_devices = {}
            
            try:
                config = kwargs
            except:
                config = {}           
            config["broadcastNewPrice"] = self.send_new_price
            config["broadcastNewPower"] = self.send_new_power
            config["broadcastNewTTIE"] = self.send_new_time_until_next_event

            self.grid_controller = GridController(config)    
            
    def get_device(self):
        return self.grid_controller        
    
    @match_exact(ADD_GENERATOR_TOPIC)
    @log_entry_and_exit
    def on_add_generator_message(self, topic, headers, message, matched):
        message = jsonapi.loads(message[0])
        device_id = headers[headers_mod.FROM]        
        price_topic = ENERGY_PRICE_TOPIC_SPECIFIC_AGENT.format(id = device_id)
        subscribe_id = self.subscribe(price_topic, self.on_generator_price_message)
        self.generators[device_id] = {"price_topic" : price_topic, "subscription_id" : subscribe_id}
        self.grid_controller.addDevice(device_id, "diesel_generator")
        
        
    @match_exact(ADD_END_USE_DEVICE_TOPIC)
    @log_entry_and_exit
    def on_add_end_use_device_message(self, topic, headers, message, matched):
        message = jsonapi.loads(message[0])
        device_id = headers["agent_id"]
        power_topic = POWER_USE_TOPIC_SPECIFIC_AGENT.format(id = device_id)
        subscribe_id = self.subscribe(power_topic, self.on_end_use_device_power_use_message)
        self.end_use_devices[device_id] = {"power_use_topic" : power_topic, "subscription_id" : subscribe_id}
        self.grid_controller.addDevice(device_id, "end_use_device")
        
    @match_exact(REMOVE_GENERATOR_TOPIC)
    @log_entry_and_exit
    def on_remove_generator_message(self, topic, headers, message, matched):
        message = jsonapi.loads(message[0])
        device_id = headers["agent_id"]
        self.unsubscribe(self.geneators[device_id]["subscription_id"])
        del self.generators[device_id]
        self.grid_controller.removeDevice(device_id, "diesel_generator")
        
        
    @match_exact(REMOVE_END_USE_DEVICE_TOPIC)
    @log_entry_and_exit
    def on_remove_end_use_device_message(self, topic, headers, message, matched):
        message = jsonapi.loads(message[0])
        device_id = headers["agent_id"]            
        del self.generators[device_id]
        self.grid_controller.removeDevice(device_id, "end_use_device")
    
    @log_entry_and_exit
    def on_end_use_device_power_use_message(self, topic, headers, message, matched):
        message = jsonapi.loads(message[0])
        device_id = headers.get("device_id", None)
        message_id = headers.get("message_id", None)
        power_use = message.get("power", None)
        timestamp = headers.get("timestamp", None)
        #response_topics_and_messages = self.update_device_power_use(device_id, power_use, message_id)        
        #self.send_response_messages(response_topics_and_messages, headers)
        self.grid_controller.onPowerChange(device_id, None, timestamp, power_use)
        
            
    @log_entry_and_exit
    def on_generator_price_message(self, topic, headers, message, matched):
        message = jsonapi.loads(message[0])
        device_id = headers.get("device_id", None)
        message_id = headers.get("message_id", None)
        price = message.get("price")        
        timestamp = headers.get("timestamp", None)
        self.grid_controller.onPriceChange(device_id, None, timestamp, price)
        
        

def main(argv=sys.argv):
    '''Main method called by the eggsecutable.'''
    utils.default_main(GridControllerAgent,
                       description='TROPEC Supervisor Agent',
                       argv=argv)


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv))
    except KeyboardInterrupt:
        pass
