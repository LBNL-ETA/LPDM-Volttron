# -*- coding: utf-8 -*- {{{
# vim: set fenc=utf-8 ft=python sw=4 ts=4 sts=4 et:


import sys
import requests
from requests import ConnectionError

from volttron.platform.agent import BaseAgent, PublishMixin
from volttron.platform.agent import utils
from volttron.platform.agent.utils import jsonapi
from volttron.platform.agent.matching import match_all, match_start, match_exact
from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import topics
from Agents.TROPEC_BaseAgent.base.topics import *
from Agents.TROPEC_SimulationAgent.simulation.agent import SimulationAgent
import json
from tug_devices.eud import Eud

def log_entry_and_exit(f):
    def _f(*args):
        print "Entering %s" % f.__name__
        f(*args)
        print "Exited %s" % f.__name__
    return _f


class EndUseDeviceAgent(SimulationAgent):
    
    def __init__(self, **kwargs):
        super(EndUseDeviceAgent, self).__init__(**kwargs)
        
        try:
            config = kwargs
        except:
            config = {}           
        config["broadcastNewPrice"] = self.send_new_price
        config["broadcastNewPower"] = self.send_new_power
        config["broadcastNewTTIE"] = self.send_new_time_until_next_event
        self.energy_subscription_id = self.subscribe(ENERGY_PRICE_TOPIC_SPECIFIC_AGENT.format(id = self.agent_id), self.on_price_update)
        self.end_use_device = Eud(config)
        self.broadcast_connection()
    
    def get_device(self):
        return self.end_use_device
    
    def broadcast_connection(self):
        headers = self.default_headers(None)
        self.publish_json(ADD_END_USE_DEVICE_TOPIC, headers, {"agent_id" : self.agent_id})
        
    def on_price_update(self, topic, headers, message, matched):
        message = jsonapi.loads(message[0])
        device_id = headers.get("device_id", None)
        message_id = headers.get("message_id", None)
        price = message.get("price_per_kwh", None)
        timestamp = headers.get("timestamp", None)
        self.end_use_device.onPriceChange(device_id, None, timestamp, price)
        
    @match_exact(ENERGY_PRICE_TOPIC)
    @log_entry_and_exit
    def on_price_update_message(self, topic, headers, message, matched):
        self.on_price_update(topic, headers, message, matched)


def main(argv=sys.argv):
    '''Main method called by the eggsecutable.'''
    utils.default_main(EndUseDeviceAgent,
                       description='TROPEC EndUseDevice Agent',
                       argv=argv)


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv))
    except KeyboardInterrupt:
        pass
