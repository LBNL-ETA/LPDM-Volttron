# -*- coding: utf-8 -*- {{{
# vim: set fenc=utf-8 ft=python sw=4 ts=4 sts=4 et:

# Copyright (c) 2013, Battelle Memorial Institute
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in
#    the documentation and/or other materials provided with the
#    distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
# OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
# THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# The views and conclusions contained in the software and documentation
# are those of the authors and should not be interpreted as representing
# official policies, either expressed or implied, of the FreeBSD
# Project.
#
# This material was prepared as an account of work sponsored by an
# agency of the United States Government.  Neither the United States
# Government nor the United States Department of Energy, nor Battelle,
# nor any of their employees, nor any jurisdiction or organization that
# has cooperated in the development of these materials, makes any
# warranty, express or implied, or assumes any legal liability or
# responsibility for the accuracy, completeness, or usefulness or any
# information, apparatus, product, software, or process disclosed, or
# represents that its use would not infringe privately owned rights.
#
# Reference herein to any specific commercial product, process, or
# service by trade name, trademark, manufacturer, or otherwise does not
# necessarily constitute or imply its endorsement, recommendation, or
# favoring by the United States Government or any agency thereof, or
# Battelle Memorial Institute. The views and opinions of authors
# expressed herein do not necessarily state or reflect those of the
# United States Government or any agency thereof.
#
# PACIFIC NORTHWEST NATIONAL LABORATORY
# operated by BATTELLE for the UNITED STATES DEPARTMENT OF ENERGY
# under Contract DE-AC05-76RL01830

#}}}

import sys
import requests
from requests import ConnectionError

from volttron.platform.agent import BaseAgent, PublishMixin
from volttron.platform.agent import utils
from volttron.platform.agent.utils import jsonapi
from volttron.platform.agent.matching import match_all, match_start
from volttron.platform.messaging import headers as headers_mod
from volttron.platform.messaging import topics

#import settings
UPLOAD_REQUEST_TOPIC = "smapinterface/request/upload"
DOWNLOAD_REQUEST_TOPIC = "smapinterface/request/download"
UPLOAD_RESPONSE_TOPIC = "smapinterface/response/upload"
DOWNLOAD_RESPONSE_TOPIC = "smapinterface/response/download"

def log_entry_and_exit(f):
    def _f(*args):
        print "Entering %s" % f.__name__
        f(*args)
        print "Exited %s" % f.__name__
    return _f

@log_entry_and_exit
def build_paths(path, result_data, timeseries, delim='/'):
    p = ''
    last_found = result_data
    for pathelement in path.split(delim):
        if pathelement in last_found:
            last_found = last_found[pathelement]
        else:
            last_found[pathelement] = {}
            last_found = last_found[pathelement]
    timeseries[path] = last_found
    return (result_data, timeseries)

def SmapInterfaceAgent(config_path, **kwargs):
    config = utils.load_config(config_path)

    def get_config(name):
        try:
            value = kwargs.pop(name)
        except KeyError:
            return config[name]

    class Agent(PublishMixin, BaseAgent):
        def __init__(self, **kwargs):
                super(Agent, self).__init__(**kwargs)
    #         self.subscribe(REQUEST_TOPIC, self.handle_request)
    
        
        @match_start(UPLOAD_REQUEST_TOPIC)
        @log_entry_and_exit
        def upload_timeseries_to_smap(self, topic, headers, message, matched):
            import uuid
            import smap_upload_data
            from dateutil.parser import parse
            message = jsonapi.loads(message[0])
            path = topic[len(UPLOAD_REQUEST_TOPIC):]
            source = headers.get('SourceName', None)
            smap_root = headers.get("SmapRoot", None)
            stream = headers.get('Stream', None)
            api_key = headers.get('ApiKey', None)
            stream_uuid = headers.get('StreamUUID', str(uuid.uuid4()))
            timeseries = message['timeseries']
            pub_headers = {headers_mod.FROM: 'SmapInterfaceAgent',
                           headers_mod.TO: headers[headers_mod.FROM] if headers_mod.FROM in headers else 'Unknown'}
            
#            try:
#                timeseries = [(parse(x[0]), x[1]) for x in timeseries]
#            except Exception as e:                
#                print "Trying to parse the timeseries threw: %s" % e
#                self.publish(UPLOAD_RESPONSE_TOPIC + path,
#                             pub_headers, "Trying to parse the timeseries threw: %s" % e)
#                return
            
            metadata = message['metadata']
            units = metadata['UnitofMeasure'] if 'UnitofMeasure' in metadata else None     
            
            try:
                res = smap_upload_data.upload(timeseries, smap_root, api_key, source, stream, stream_uuid, units, additional_metadata = metadata)
            except Exception as e:
                self.publish(UPLOAD_RESPONSE_TOPIC + path,
                             pub_headers, "Trying to upload the timeseries threw: %s" % e)
                return
            
            if res == False:
                self.publish(UPLOAD_RESPONSE_TOPIC + path,
                             pub_headers, "Trying to upload to smap failed.")
            else:
                self.publish(UPLOAD_RESPONSE_TOPIC + path,
                             pub_headers, "Success")

                                
        @match_start(DOWNLOAD_REQUEST_TOPIC)
        @log_entry_and_exit
        def download_timeseries_from_smap(self, topic, headers, message, matched):
            from smap_download_data import download_data
            path = topic[len(DOWNLOAD_REQUEST_TOPIC):]
            
            # Range is message.  It will either be "start"-"end" or 1h, 1d,
            # etc... from now
#            range_str = message[0]
#            message = jsonapi.loads(message[0])
            stream = topic[len(DOWNLOAD_REQUEST_TOPIC):]
            source = headers.get('SourceName', None)
            smap_root = headers.get("SmapRoot", None)            
            start_time = headers.get('StartTime', None)
            end_time = headers.get('EndTime', None)                        
            
            print "source: %s path: %s" % (source, path)            
            data, timezone = download_data(smap_root, stream, source_name = source, start_time = start_time, end_time = end_time)
            message = {"timeseries" : data, "timezone" : timezone}
            
            pub_headers = {headers_mod.FROM: 'SmapInterfaceAgent',
                           headers_mod.TO: headers[headers_mod.FROM] if headers_mod.FROM in headers else 'Unknown'}
            self.publish_json(DOWNLOAD_RESPONSE_TOPIC + path, pub_headers, message)
        
    Agent.__name__ = 'SmapInterfaceAgent'
    return Agent(**kwargs)

def main(argv=sys.argv):
    '''Main method called by the eggsecutable.'''
    utils.default_main(SmapInterfaceAgent,
                       description='VOLTTRON Lite™ sMAP interface agent',
                       argv=argv)


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv))
    except KeyboardInterrupt:
        pass
