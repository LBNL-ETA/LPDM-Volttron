# -*- coding: utf-8 -*- {{{
# vim: set fenc=utf-8 ft=python sw=4 ts=4 sts=4 et:


import sys
import requests
from requests import ConnectionError

from volttron.platform.agent import BaseAgent, PublishMixin
from volttron.platform.agent import utils
from volttron.platform.agent.utils import jsonapi
from volttron.platform.agent.matching import match_all, match_start
from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import topics
from Agents.TROPEC_BaseAgent.base.agent import TROPEC_BaseAgent
import json

SYSTEM_TIME_TOPIC = "system_time"

def log_entry_and_exit(f):
    def _f(*args):
        print "Entering %s" % f.__name__
        f(*args)
        print "Exited %s" % f.__name__
    return _f



class SimulationAgent(PublishMixin, TROPEC_BaseAgent):
    def __init__(self, agent_id, **kwargs):
            super(TROPEC_BaseAgent, self).__init__(agent_id, **kwargs)
            self.time = 0

    @match_start(SYSTEM_TIME_TOPIC)
    @log_entry_and_exit
    def on_time_update(self, topic, headers, message, matched):
        headers = self.get_response_headers(headers)
        message = jsonapi.loads(message[0])
        timestamp = message["time"]
        self.time = float(timestamp)
        
    def get_time(self):
        return self.time
            

def main(argv=sys.argv):
    '''Main method called by the eggsecutable.'''
    utils.default_main(SimulationAgent,
                       description='TROPEC Simulation Agent',
                       argv=argv)


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv))
    except KeyboardInterrupt:
        pass
