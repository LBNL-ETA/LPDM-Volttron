# -*- coding: utf-8 -*- {{{
# vim: set fenc=utf-8 ft=python sw=4 ts=4 sts=4 et:


import sys
import requests
from requests import ConnectionError

from volttron.platform.agent import BaseAgent, PublishMixin
from volttron.platform.agent import utils
from volttron.platform.agent.utils import jsonapi
from volttron.platform.agent.matching import match_all, match_start
from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import topics

import json

TIME_UNTIL_NEXT_EVENT_TOPIC_GLOBAL = "time_until_next_event"
TIME_UNTIL_NEXT_EVENT_TOPIC_SPECIFIC_AGENT = TIME_UNTIL_NEXT_EVENT_TOPIC_GLOBAL + "/{id}" 

def log_entry_and_exit(f):
    def _f(*args):
        print "Entering %s" % f.__name__
        f(*args)
        print "Exited %s" % f.__name__
    return _f



class TROPEC_BaseAgent(PublishMixin, BaseAgent):
    def __init__(self, agent_id, **kwargs):
            super(BaseAgent, self).__init__(**kwargs)
            self.time = None
            self.agent_id = agent_id
            self.subscribe(TIME_UNTIL_NEXT_EVENT_TOPIC_GLOBAL, self.on_time_until_next_event_request)
            self.subscribe(TIME_UNTIL_NEXT_EVENT_TOPIC_SPECIFIC_AGENT.format(id = self.agent_id), self.on_time_until_next_event_request)
            
    def on_time_until_next_event_request(self, topic, headers, message, matched):
        response_topics_and_messages = self.get_time_until_next_event(message)
        self.send_response_messages(response_topics_and_messages, headers)
        
    def get_time_until_next_event(self, message):
        raise NotImplementedError("Implement in derived class")
    
    def get_response_headers(self, headers):
        headers[headers_mod.TO] = headers[headers_mod.FROM] if headers_mod.FROM in headers else "Unknown"
        headers[headers_mod.FROM] = self.agent_id
        if "message_id" in headers:
            headers["id_of_message_triggering_response"] = headers["message_id"]
        message_timestamp = self.get_time()
        headers["sent_time"] = message_timestamp            
        headers["message_id"] = "{id} {ts}".format(id = self.agent_id, ts = message_timestamp)
    
        return headers

    def send_response_messages(self, response_topics_and_messages, headers):
        if response_topics_and_messages:
            response_headers = self.get_response_headers(headers)
            for topic, message in response_topics_and_messages.items():                
                self.publish_json(topic, response_headers, message)
    
    def get_time(self):
        raise NotImplementedError("Implement in derived class.")        
            

def main(argv=sys.argv):
    '''Main method called by the eggsecutable.'''
    utils.default_main(TROPEC_BaseAgent,
                       description='TROPEC Simulation Agent',
                       argv=argv)


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv))
    except KeyboardInterrupt:
        pass
