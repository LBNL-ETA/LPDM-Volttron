# -*- coding: utf-8 -*- {{{
# vim: set fenc=utf-8 ft=python sw=4 ts=4 sts=4 et:


import sys
import requests
from requests import ConnectionError

from volttron.platform.agent import BaseAgent, PublishMixin
from volttron.platform.agent import utils
from volttron.platform.agent.utils import jsonapi
from volttron.platform.agent.matching import match_all, match_start
from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import topics

import json

ENERGY_PRICE_TOPIC = "energy_price"
POWER_USE_TOPIC = "power_use/{id}"

def log_entry_and_exit(f):
    def _f(*args):
        print "Entering %s" % f.__name__
        f(*args)
        print "Exited %s" % f.__name__
    return _f


class GeneratorAgent(PublishMixin, BaseAgent):
    
    def __init__(self, **kwargs):
            super(BaseAgent, self).__init__(**kwargs)
#         self.subscribe(REQUEST_TOPIC, self.handle_request)

    def on_new_power(self, price):
        raise NotImplementedError("Should be implemented by subclass")
        
    @match_start(POWER_USE_TOPIC)
    @log_entry_and_exit
    def on_power_update(self, topic, headers, message, matched):        
        message = jsonapi.loads(message[0])
        power = message["power"]        
        response_topics_and_messages = self.on_new_power(power)        
        self.send_response_messages(response_topics_and_messages, headers)

def main(argv=sys.argv):
    '''Main method called by the eggsecutable.'''
    utils.default_main(GeneratorAgent,
                       description='TROPEC Generator Agent',
                       argv=argv)


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv))
    except KeyboardInterrupt:
        pass
