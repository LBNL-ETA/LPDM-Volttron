# -*- coding: utf-8 -*- {{{
# vim: set fenc=utf-8 ft=python sw=4 ts=4 sts=4 et:


import sys
import requests
from requests import ConnectionError

from volttron.platform.agent import BaseAgent, PublishMixin
from volttron.platform.agent import utils
from volttron.platform.agent.utils import jsonapi
from volttron.platform.agent.matching import match_all, match_start, match_exact
from volttron.platform.messaging import headers as headers_mod
from Agents.TROPEC_SimulationAgent.simulation.agent import SimulationAgent
#from volttron.platform.messaging import headers as headers_mod
#from volttron.platform.messaging import topics

import json

BASE_SUBSCRIPTION_TOPIC = "grid_controller/{uuid}"
BASE_ADD_CONTROLLED_DEVICE_TOPIC = BASE_SUBSCRIPTION_TOPIC + "/add" 
ADD_GENERATOR_TOPIC = BASE_ADD_CONTROLLED_DEVICE_TOPIC + "/generator" 
ADD_END_USE_DEVICE_TOPIC = BASE_ADD_CONTROLLED_DEVICE_TOPIC + "/end_use_device"
REMOVE_GENERATOR_TOPIC = ADD_GENERATOR_TOPIC.replace("/add", "/remove") 
REMOVE_END_USE_DEVICE_TOPIC = ADD_END_USE_DEVICE_TOPIC.replace("/add", "/remove")

def log_entry_and_exit(f):
    def _f(*args):
        print "Entering %s" % f.__name__
        f(*args)
        print "Exited %s" % f.__name__
    return _f


class GridControllerAgent(PublishMixin, SimulationAgent):
   
    def __init__(self, **kwargs):
            #super(BaseAgent, self).__init__(**kwargs)
            super(SimulationAgent, self).__init__(**kwargs)
            self.geneators = {}
            self.end_use_devices = {}            
    
    @match_exact(ADD_GENERATOR_TOPIC)
    @log_entry_and_exit
    def on_add_generator_message(self, topic, headers, message, matched):
        message = jsonapi.loads(message[0])
        device_id = headers["device_id"]
        price_topic = message["price_topic"]
        subscribe_id = self.subscribe(price_topic, self.on_generator_price_message)
        self.generators[device_id] = {"price_topic" : price_topic, "subscription_id" : subscribe_id}
        
        
    @match_exact(ADD_END_USE_DEVICE_TOPIC)
    @log_entry_and_exit
    def on_add_end_use_device_message(self, topic, headers, message, matched):
        message = jsonapi.loads(message[0])
        device_id = headers["device_id"]
        energy_price_topic = message["energy_price"]            
        self.generators[device_id] = {"energy_price" : energy_price_topic}
        
    @match_exact(REMOVE_GENERATOR_TOPIC)
    @log_entry_and_exit
    def on_remove_generator_message(self, topic, headers, message, matched):
        message = jsonapi.loads(message[0])
        device_id = headers["device_id"]
        self.unsubscribe(self.geneators[device_id]["subscription_id"])
        del self.generators[device_id]
        
        
    @match_exact(REMOVE_END_USE_DEVICE_TOPIC)
    @log_entry_and_exit
    def on_remove_end_use_device_message(self, topic, headers, message, matched):
        message = jsonapi.loads(message[0])
        device_id = headers["device_id"]            
        del self.generators[device_id]
    
    @log_entry_and_exit
    def on_end_use_device_power_use_message(self, topic, headers, message, matched):
        message = jsonapi.loads(message[0])
        device_id = headers.get("device_id", None)
        message_id = headers.get("message_id", None)
        power_use = message.get("power", None)
        response_topics_and_messages = self.update_device_power_use(device_id, power_use, message_id)        
        self.send_response_messages(response_topics_and_messages, headers)
        
        
    def update_device_power_use(self, device_id, power_use, message_id = None):
        pass                           
            
    @log_entry_and_exit
    def on_generator_price_message(self, topic, headers, message, matched):
        message = jsonapi.loads(message[0])
        device_id = headers.get("device_id", None)
        message_id = headers.get("message_id", None)
        price = message.get("price")        
        response_topics_and_messages = self.update_energy_price(device_id, price, message_id)        
        self.send_response_messages(response_topics_and_messages, headers)
        
    def update_energy_price(self, generator_id, new_price, message_id = None):
        pass
        

def main(argv=sys.argv):
    '''Main method called by the eggsecutable.'''
    utils.default_main(GridControllerAgent,
                       description='TROPEC Supervisor Agent',
                       argv=argv)


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv))
    except KeyboardInterrupt:
        pass
