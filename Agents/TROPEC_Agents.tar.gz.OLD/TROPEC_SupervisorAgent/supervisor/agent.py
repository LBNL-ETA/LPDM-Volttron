# -*- coding: utf-8 -*- {{{
# vim: set fenc=utf-8 ft=python sw=4 ts=4 sts=4 et:


import sys
import requests
from requests import ConnectionError

from volttron.platform.agent import BaseAgent, PublishMixin
from volttron.platform.agent import utils
from volttron.platform.agent.utils import jsonapi
from volttron.platform.agent.matching import match_all, match_start
from volttron.platform.messaging import headers as headers_mod
from volttron.platform.messaging import topics


TOPIC_TO_RESPOND_TO = "something/something_else"
SYSTEM_TIME_TOPIC = "system_time"

def log_entry_and_exit(f):
    def _f(*args):
        print "Entering %s" % f.__name__
        f(*args)
        print "Exited %s" % f.__name__
    return _f

#class Managed_Agent_Info(object):
#    def __init__(self, agent_id, agent_time_topic, agent_next_event_topic):
#        self.agent_id = agent_id
#        self.agent_time_topic = agent_time_topic
#        self.agent_next_event_topic = agent_next_event_topic


class SupervisorAgent(PublishMixin, BaseAgent):
    def __init__(self, **kwargs):
        super(BaseAgent, self).__init__(**kwargs)        
        self.time = 0
        self.agent_id = 0
        self.managed_agent_information = {} #key is agent_id, value is dict with keys agent_time_topic and agent_next_event_topic
        self.expected_next_event_replies = {}

    def send_next_event_request(self, agent_id):
        headers = {}        
        headers[headers_mod.FROM] = self.agent_id
        message_timestamp = self.time
        headers["sent_time"] = message_timestamp
        headers["message_id"] = "{id} {ts}".format(id = self.agent_id, ts = message_timestamp)
        message = {"time" : self.time}
        self.expected_next_event_replies[agent_id] = {"message_id" : headers["message_id"], "response_message" : None, "response_headers" : None}
        self.post_json(self.managed_agent_information[agent_id]["agent_next_event_topic"], headers, message)
        
    def poll_for_next_event(self, agent_ids = None):
        self.expected_next_event_replies = {}
        
        if not agent_ids:
            agent_ids = self.managed_agent_information.keys()
            
        for agent_id in agent_ids:
            self.send_next_event_request(agent_id)
            

    @match_start(TOPIC_TO_RESPOND_TO)
    @log_entry_and_exit
    def respond_to_something(self, topic, headers, message, matched):
        pass

def main(argv=sys.argv):
    '''Main method called by the eggsecutable.'''
    utils.default_main(SupervisorAgent,
                       description='TROPEC Supervisor Agent',
                       argv=argv)


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv))
    except KeyboardInterrupt:
        pass
